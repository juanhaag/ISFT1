#include <iostream>
#include "funciones.h"

int main(int argc, char const *argv[])
{
    solicitudList solicitudes;
    runCrud(solicitudes);
    return 0;
}
